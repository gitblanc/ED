package examenGrafos2023;

import java.text.DecimalFormat;

/**
 * @author Profesores ED 2023
 * @version 2023-24
 */
public class GraphEx2023<T> {
	/**
	 * Constante infinito
	 */
	protected static final double Inf = Double.POSITIVE_INFINITY;

	/**
	 * Vector de nodos
	 */
	protected T[] nodes; // Vector de nodos
	/**
	 * Matriz de aristas
	 */
	protected boolean[][] edges; // matriz de aristas
	/**
	 * Matriz de pesos
	 */
	protected double[][] weights; // matriz de pesos

	/**
	 * Numero de elementos en un momento dado
	 */
	protected int numNodes; // numero de elementos en un momento dado

	// PARA FLOYD
	protected double[][] A;
	protected int[][] P;

	/**
	 * 
	 * @param tam Numero maximo de nodos del grafo
	 */
	@SuppressWarnings("unchecked")
	public GraphEx2023(int tam) {
		nodes = (T[]) new Object[tam];
		numNodes = 0;
		edges = new boolean[tam][tam];
		weights = new double[tam][tam];
	}

	public int getNumMaxNodes() {
		return nodes.length;
	}

	protected int getNumNodes() {
		return numNodes;
	}

	protected T[] getNodes() {
		return nodes;
	}

	protected boolean[][] getEdges() {
		return edges;
	}

	protected double[][] getWeights() {
		return weights;
	}

	/**
	 * Obtiene el indice de un nodo en el vector de nodos
	 * 
	 * @param node que es el nodo que se busca
	 * @return la posicion del nodo en el vector, -1 si no se encuentra
	 */
	protected int getNodeEx(T node) {
		for (int i = 0; i < numNodes; i++) {
			if (nodes[i].equals(node)) {
				return i;
			}
		}
		return -1;
	}

	/**
	 * Inserta un nuevo nodo que se le pasa como parametro. Siempre lo inserta, no
	 * se controlan casos en que no lo pueda hacer
	 * 
	 * @param node el nodo que se quiere insertar
	 * @return true siempre
	 */
	public boolean addNodeEx(T node) {
		nodes[numNodes] = node;
		for (int i = 0; i <= numNodes; i++) {
			edges[numNodes][i] = false;
			edges[i][numNodes] = false;
		}
		numNodes++;
		return true;
	}

	/**
	 * Inserta una arista entre dos nodos con el peso indicado Devuelve true siempre
	 * No comprueba nada.
	 * 
	 * @param source     nodo origen
	 * @param target     nodo destino
	 * @param edgeWeight peso de la arista
	 * @return true siempre
	 */
	public boolean addEdgeEx(T source, T target, double edgeWeight) {
		int posOrigen = getNodeEx(source);
		int posDestino = getNodeEx(target);
		edges[posOrigen][posDestino] = true;
		weights[posOrigen][posDestino] = edgeWeight;
		return true;
	}

	/**
	 * Borra la arista del grafo que conecta dos nodos. Siempre la borra sin
	 * comprobar nada
	 * 
	 * @param source Nodo origen de la arista
	 * @param target Nodo destino de la arista
	 * @return true siempre
	 */
	public boolean removeEdgeEx(T source, T target) {
		int posOrigen = getNodeEx(source);
		int posDestino = getNodeEx(target);
		edges[posOrigen][posDestino] = false;
		return true;
	}

	/**
	 * Devuelve el peso de la arista que conecta dos nodos. No comprueba nada...
	 * 
	 * @param source Nodo origen de la arista
	 * @param target Nodo destino de la arista
	 * @return El peso de la arista
	 */
	public double getEdgeEx(T source, T target) {
		int posOrigen = getNodeEx(source);
		int posDestino = getNodeEx(target);
		return weights[posOrigen][posDestino];
	}

	/**
	 * @return Devuelve un String con la informacion del grafo usando StringBuilder
	 */
	public String toString() {
		DecimalFormat df = new DecimalFormat("#.##");
		StringBuilder cadena = new StringBuilder();

		cadena.append("NODES\n");
		for (int i = 0; i < numNodes; i++) {
			cadena.append(nodes[i].toString() + "\t");
		}
		cadena.append("\n\nEDGES\n");
		for (int i = 0; i < numNodes; i++) {
			for (int j = 0; j < numNodes; j++) {
				if (edges[i][j])
					cadena.append("T\t");
				else
					cadena.append("F\t");
			}
			cadena.append("\n");
		}
		cadena.append("\nWEIGHTS\n");
		for (int i = 0; i < numNodes; i++) {
			for (int j = 0; j < numNodes; j++) {

				cadena.append((edges[i][j] ? df.format(weights[i][j]) : "-") + "\t");
			}
			cadena.append("\n");
		}

		double[][] aFloyd = getAFloyd();
		if (aFloyd != null) {
			cadena.append("\nAFloyd\n");
			for (int i = 0; i < numNodes; i++) {
				for (int j = 0; j < numNodes; j++) {
					cadena.append(df.format(aFloyd[i][j]) + "\t");
				}
				cadena.append("\n");
			}
		}

		int[][] pFloyd = getPFloyd();
		if (pFloyd != null) {
			cadena.append("\nPFloyd\n");
			for (int i = 0; i < numNodes; i++) {
				for (int j = 0; j < numNodes; j++) {
					cadena.append((pFloyd[i][j] >= 0 ? df.format(pFloyd[i][j]) : "-") + "\t");
				}
				cadena.append("\n");
			}
		}
		return cadena.toString();
	}

	/**
	 * Aplica el algoritmo de Floyd al grafo actual Devuelve true si lo aplica y
	 * false en caso contrario (no hay nodos en el grafo)
	 */
	public boolean floydEx() {
		// No hay nodos en el grafo
		if (getSize() == 0)
			return false;

		inicializaA();
		inicializaP();

		for (int pivote = 0; pivote < getSize(); pivote++) {
			for (int source = 0; source < getSize(); source++) {
				for (int target = 0; target < getSize(); target++) {
					if (getAFloyd()[source][pivote] + getAFloyd()[pivote][target] < getAFloyd()[source][target]) {
						this.A[source][target] = getAFloyd()[source][pivote] + getAFloyd()[pivote][target];
						this.P[source][target] = pivote;
					}
				}
			}
		}

		return true;
	}

	// Número de nodos del grafo
	private int getSize() {
		return this.numNodes;
	}

	private void inicializaP() {
		this.P = new int[getSize()][getSize()];
		for (int i = 0; i < getSize(); i++) {
			for (int j = 0; j < getSize(); j++) {
				this.P[i][j] = -1;
			}
		}
	}

	private void inicializaA() {
		this.A = new double[getSize()][getSize()];
		for (int i = 0; i < getSize(); i++) {
			for (int j = 0; j < getSize(); j++) {
				if (i == j)
					this.A[i][j] = 0;
				else if (existsEdge(this.nodes[i], this.nodes[j]))
					this.A[i][j] = getEdgeEx(this.nodes[i], this.nodes[j]);
				else
					this.A[i][j] = Double.POSITIVE_INFINITY;
			}
		}
	}

	private boolean existsEdge(T n1, T n2) {
		return this.edges[getNodeEx(n1)][getNodeEx(n2)];
	}

	/**
	 * Devuelve la matriz A de Floyd, con infinito si no hay camino Si no se ha
	 * invocado a Floyd debe devolver null (ojo que no lo invoca) La matriz devuelta
	 * debe ser de tamaño: double[numNodes][numNodes]
	 * 
	 * @return la matriz A de Floyd
	 */
	protected double[][] getAFloyd() {
		return this.A;
	}

	/**
	 * Devuelve la matriz P de Floyd, con -1 en las posiciones en las que no hay
	 * nodo intermedio Si no se ha invocado a Floyd debe devolver null (ojo que no
	 * lo invoca) La matriz devuelta debe ser de tamaño: int[numNodes][numNodes]
	 * 
	 * @return la matriz P de Floyd
	 */
	protected int[][] getPFloyd() {
		return this.P;
	}

	/**
	 * Calcula si el nodo es accesible desde cualquier nodo del grafo
	 * 
	 * @param origen El nodo origen
	 * @return true o false si es accesible o no
	 */
	public boolean esAccesible(T nodo) {
		floydEx();

		int posNode = getNodeEx(nodo);

		for (int i = 0; i < getSize(); i++) {
			for (int j = 0; j < getSize(); j++) {
				if (this.A[i][posNode] == Double.POSITIVE_INFINITY)
					return false;
			}

		}

		return true;
	}

	/**
	 * Calcula el número de nodos no accesibles desde el nodo parámetro Si el nodo
	 * origen no existe en el grafo, devuelve -1
	 * 
	 * @param origen El nodo origen
	 * @return el numero de nodos NO accesibles desde el nodo origen
	 */
	public int getNumberOfUnreachablesNodes(T nodo) {
		if (!existsNode(nodo))
			return -1;

		int unreachables = 0;

		for (int i = 0; i < getSize(); i++) {
			if (!esAccesibleDesdeNodo(nodo, this.nodes[i]))
				unreachables += 1;
		}

		return unreachables;
	}

	private boolean esAccesibleDesdeNodo(T source, T target) {
		floydEx();

		int posSource = getNodeEx(source);
		int posTarget = getNodeEx(target);

		return getAFloyd()[posSource][posTarget] != Double.POSITIVE_INFINITY;
	}

	private boolean existsNode(T nodo) {
		if (nodo == null || getNodeEx(nodo) == -1)
			return false;
		return true;

	}

}
