package examenGrafos2023;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class GraphEx2023TestFloydBasic {
	private static final double Inf=Double.POSITIVE_INFINITY;

	@Test
	public void FloydGrafoEvolucionado() {

		int k=0;
		GraphEx2023<Character> gc=new GraphEx2023<>(7);
		for (char i='a';i<='g';i++ ) {
			assertTrue(gc.addNodeEx(i));
		}
		for (char i='a';i<='g';i++ ) 
			for (char j='a';j<='g';j++ ) 
				assertTrue(gc.addEdgeEx(i,j,i>j?1000-(i+j)/10*++k:(i+j)/10*++k));

		assertTrue(gc.floydEx());
		assertArrayEquals(new double[][]{
					{ 0 , 38 , 57 , 76 , 95 , 114 , 140 },
					{ 420 , 0 , 190 , 209 , 228 , 260 , 280 },
					{ 560 , 540 , 0 , 342 , 380 , 400 , 420 },
					{ 582 , 563 , 544 , 0 , 520 , 540 , 560 },
					{ 449 , 430 , 380 , 360 , 0 , 563 , 589 },
					{ 316 , 260 , 240 , 220 , 200 , 0 , 456 },
					{ 140 , 120 , 100 , 80 , 60 , 40 , 0 }
				}
				,gc.getAFloyd()
				,"Error en A de Floyd con este grafo con todas las aristas:\n"+gc.toString()) ;

			assertArrayEquals(new int[][]{
					{ -1  ,  -1  ,  -1  ,  -1  ,  -1  ,  -1  ,  -1 },
					 {6 ,  -1  ,  -1  ,  -1  ,  -1  ,  -1  ,  -1 },
					 {6 , 6 ,  -1  ,  -1  ,  -1  ,  -1  ,  -1 },
					 { -1  ,  -1  ,  -1  ,  -1  ,  -1  ,  -1  ,  -1 },
					 { -1  ,  -1  ,  -1  ,  -1  ,  -1  , 0 , 0},
					 { -1  ,  -1  ,  -1  ,  -1  ,  -1  ,  -1  , 0},
					 { -1  ,  -1  ,  -1  ,  -1  ,  -1  ,  -1  ,  -1 }
				}
				,gc.getPFloyd()
				,"Error en P de Floyd con este grafo con todas las aristas:\n"+gc.toString());


		for (char i='a';i<='g';i++ ) 
			for (char j='a';j<='g';j++ ) 
				assertTrue(gc.removeEdgeEx(i,j));
		
		assertTrue(gc.floydEx());
		assertArrayEquals(new double[][]
			{{ 0 , Inf , Inf , Inf , Inf , Inf , Inf },
			 { Inf , 0 , Inf , Inf , Inf , Inf , Inf },
			 { Inf , Inf , 0 , Inf , Inf , Inf , Inf },
			 { Inf , Inf , Inf , 0 , Inf , Inf , Inf },
			 { Inf , Inf , Inf , Inf , 0 , Inf , Inf },
			 { Inf , Inf , Inf , Inf , Inf , 0 , Inf },
			 { Inf , Inf , Inf , Inf , Inf , Inf , 0 }}
			,gc.getAFloyd()
			,"Error en A de Floyd con este grafo despues de haberle borrado todas las aristas:\n"+gc.toString()) ;

		assertArrayEquals(new int[][]
			{{ -1  ,  -1  ,  -1  ,  -1  ,  -1  ,  -1  ,  -1 },
			 { -1  ,  -1  ,  -1  ,  -1  ,  -1  ,  -1  ,  -1 },
			 { -1  ,  -1  ,  -1  ,  -1  ,  -1  ,  -1  ,  -1 },
			 { -1  ,  -1  ,  -1  ,  -1  ,  -1  ,  -1  ,  -1 },
			 { -1  ,  -1  ,  -1  ,  -1  ,  -1  ,  -1  ,  -1 },
			 { -1  ,  -1  ,  -1  ,  -1  ,  -1  ,  -1  ,  -1 },
			 { -1  ,  -1  ,  -1  ,  -1  ,  -1  ,  -1  ,  -1 }}
			,gc.getPFloyd()
			,"Error en P de Floyd con este grafo despues de haberle borrado todas las aristas:\n"+gc.toString());

	}
}
