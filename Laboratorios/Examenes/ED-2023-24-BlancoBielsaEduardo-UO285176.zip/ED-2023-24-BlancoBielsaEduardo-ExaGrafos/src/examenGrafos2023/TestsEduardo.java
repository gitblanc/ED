package examenGrafos2023;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestsEduardo {

	@Test
	void testEsAccesible1() {
		GraphEx2023<Character> graph = new GraphEx2023<>(5);
		for (char i = 'a'; i <= 'd'; i++) {
			assertTrue(graph.addNodeEx(i));
		}

		graph.addEdgeEx('a', 'b', 4);
		graph.addEdgeEx('b', 'c', 5);
		graph.addEdgeEx('b', 'd', 1);

		assertEquals(false, graph.esAccesible('b'));
		assertEquals(false, graph.esAccesible('a'));
		assertEquals(false, graph.esAccesible('c'));
		assertEquals(false, graph.esAccesible('d'));

		graph.addNodeEx('e');
		graph.addEdgeEx('c', 'e', 3);
		graph.addEdgeEx('d', 'e', 10);
		graph.addEdgeEx('e', 'b', 8);

		assertEquals(true, graph.esAccesible('b'), "error implementacion");
	}

	@Test
	void testEsAccesible2() {
		GraphEx2023<Character> graph = new GraphEx2023<>(5);
		for (char i = 'a'; i <= 'b'; i++) {
			assertTrue(graph.addNodeEx(i));
		}

		graph.addEdgeEx('a', 'b', 4);

		assertEquals(true, graph.esAccesible('b'));

		graph.addNodeEx('c');

		assertEquals(false, graph.esAccesible('b'));
		assertEquals(false, graph.esAccesible('c'));

		graph.addEdgeEx('b', 'c', 2);

		assertEquals(true, graph.esAccesible('c'));
	}

	@Test
	void testNumberOfUnreachablesNodes1() {
		GraphEx2023<Character> graph = new GraphEx2023<>(5);
		for (char i = 'a'; i <= 'b'; i++) {
			assertTrue(graph.addNodeEx(i));
		}

		graph.addEdgeEx('a', 'b', 4);

		assertEquals(0, graph.getNumberOfUnreachablesNodes('a'));

		graph.addNodeEx('c');

		assertEquals(1, graph.getNumberOfUnreachablesNodes('a'));

		graph.addEdgeEx('b', 'c', 2);

		assertEquals(0, graph.getNumberOfUnreachablesNodes('a'));
	}

	@Test
	void testNumberOfUnreachablesNodes2() {
		GraphEx2023<Character> graph = new GraphEx2023<>(8);
		for (char i = 'a'; i <= 'h'; i++) {
			assertTrue(graph.addNodeEx(i));
		}

		graph.addEdgeEx('a', 'h', 1);
		graph.addEdgeEx('a', 'g', 2);
		graph.addEdgeEx('a', 'e', 3);
		graph.addEdgeEx('d', 'h', 4);
		graph.addEdgeEx('f', 'd', 7);
		graph.addEdgeEx('g', 'c', 5);
		graph.addEdgeEx('g', 'e', 6);

		assertEquals(3, graph.getNumberOfUnreachablesNodes('a'));

		assertEquals(7, graph.getNumberOfUnreachablesNodes('b'));

		assertEquals(7, graph.getNumberOfUnreachablesNodes('c'));

		assertEquals(6, graph.getNumberOfUnreachablesNodes('d'));

		assertEquals(7, graph.getNumberOfUnreachablesNodes('e'));

		assertEquals(5, graph.getNumberOfUnreachablesNodes('f'));

		assertEquals(5, graph.getNumberOfUnreachablesNodes('g'));

		assertEquals(7, graph.getNumberOfUnreachablesNodes('h'));
	}

}
